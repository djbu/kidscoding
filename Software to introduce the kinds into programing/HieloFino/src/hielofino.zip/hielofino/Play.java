package hielofino;

import java.awt.Point;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.*;
import org.newdawn.slick.state.*;
/**
 *
 * @author Diego André
 */
public class Play extends BasicGameState{

    float a=0;
    boolean b=true;
    
    public static final int DezArriba=0;
    public static final int DezAbajo=1;
    public static final int DezIzquierda=2;
    public static final int DezDerecha=3;
    
    private final int velocidadAgua,velocidadMuñeco;    
    private final int velocidadDeMovimiento;
    
    private org.newdawn.slick.geom.Point dirMuñe;
    
    private ArrayList<Image> listImagenes;    
    private Menu menu;
    
    private int tim;
    
    private int matInterpretada[][];
    private int direccion,pasos;
    private Point posicionMuñe;
    private boolean tareaEjecutada;
    
    private SpriteSheet aguaFrames;
    private Animation muñeco;
    private Animation matAnimaciones[][];
    
    private ListadeMovimientos listOrdenes;
    
    private Sound caminar;
    
    public Play(int state,  ArrayList<Image> listImagenes, Menu menu ) 
    {
        velocidadAgua=90;
        velocidadMuñeco=80;
        velocidadDeMovimiento=300;
        
        this.listImagenes = listImagenes;
        this.menu = menu;
        
        direccion = -1;
        pasos=-1;
        
        tareaEjecutada = true;
    }

    
    @Override
    public int getID() {
       return 1;
    }

    @Override
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        
        caminar = new Sound("Audio\\caminar.wav");
        
        aguaFrames = new SpriteSheet("Icons\\mapa\\aguaAnim.png", 52, 52);
        muñeco = new Animation( new SpriteSheet("Icons\\mapa\\muñecoAnim.png", 52, 52),velocidadMuñeco);
        
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {

        /*grphcs.drawLine(150, 150, a, a);
        grphcs.drawLine(150, 150, -a, a);        
        grphcs.drawLine(150, 150, a, -a);*/
        
        for (int i = 0; i < menu.mapaActualMat.length; i++) {
            for (int j = 0; j < menu.mapaActualMat[0].length; j++) 
            {
                int cuadro = matInterpretada[i][j];
                
                switch (cuadro)
                {
                    case Game.agua:
                        matAnimaciones[i][j].draw(j*menu.dimenIma, i*menu.dimenIma, menu.dimenIma, menu.dimenIma);
                    break;
                    case Game.muñeco:
                        matAnimaciones[i][j].draw(dirMuñe.getX(), dirMuñe.getY() , menu.dimenIma, menu.dimenIma);
                    break;    
                    default:
                       Image im = listImagenes.get( cuadro );
                       grphcs.drawImage( im, j*menu.dimenIma, i*menu.dimenIma, (j+1)*menu.dimenIma, (i+1)*menu.dimenIma, 0, 0, im.getWidth(), im.getHeight()); 
                    break;
                }
                
             }
        }
        
        muñeco.draw(dirMuñe.getX(), dirMuñe.getY(), menu.dimenIma, menu.dimenIma);
        
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
       
        
        if(listOrdenes != null)
        {
            tim += i;
        
            if(tim >= velocidadDeMovimiento )
            {
                tim =0;
                //si ya termino de hacer todos los pasos
                if(tareaEjecutada)
                {
                   tareaEjecutada=false;
                   listOrdenes.sacarMovimiento();
                    System.out.println("Actividades restantes: "+ listOrdenes.getMovimientosRestantes()  );
                      direccion = listOrdenes.getDir();
                   pasos = listOrdenes.getPasos();
                }
                else
                {
                    desplazarMat();
                }
            }
        }
        
        
    }
    
    public void stateEntered(ListadeMovimientos listOrdenes)
    {
        matInterpretada = new int[ menu.mapaActualMat.length ][ menu.mapaActualMat[0].length ];
        matAnimaciones = new Animation[ menu.mapaActualMat.length ][ menu.mapaActualMat[0].length ];
        
        for (int i = 0; i < menu.mapaActualMat.length; i++) {
            for (int j = 0; j < menu.mapaActualMat[0].length; j++) 
            {
                matInterpretada[i][j]=menu.mapaActualMat[i][j];
                
                if(matInterpretada[i][j]==Game.muñeco)
                {
                    posicionMuñe = new Point(j, i);
                    dirMuñe = new org.newdawn.slick.geom.Point(j*menu.dimenIma, i*menu.dimenIma);
                }
                
                if( matInterpretada[i][j]==Game.hielo || matInterpretada[i][j]==Game.hieloDoble || matInterpretada[i][j]==Game.muñeco)
                {  
                    Animation auxAgu = new Animation(aguaFrames, velocidadAgua);
                    matAnimaciones[i][j]= auxAgu;
                }
                
                
            }
        }
        
        this.listOrdenes = listOrdenes;
        tim=0;
    }

    public void setListOrdenes(ListadeMovimientos listOrdenes) {
        this.listOrdenes = listOrdenes;
    }
    
    
    
    
    //aquí van todos las validaciones del desplazamiento
    public void desplazarMat()
    {
        
       // matInterpretada[posicionMuñe.y][posicionMuñe.x]=Game.agua;
        int cosa = 0;
            switch (direccion)
            {
                case DezAbajo:
                    
                    cosa = matInterpretada[posicionMuñe.y+1][posicionMuñe.x];
                                        
                    if( puedeAvanzar(cosa) )
                    {
                       posicionMuñe.y += 1;
                    }
                    
                break;
                case DezArriba:
                    
                    cosa = matInterpretada[posicionMuñe.y-1][posicionMuñe.x];
                    
                    if( puedeAvanzar(cosa) )
                    {
                        posicionMuñe.y -= 1;
                    }
                    
                break;
                case DezDerecha:
                    
                    cosa = matInterpretada[posicionMuñe.y][posicionMuñe.x+1];
                   
                    if( puedeAvanzar(cosa) )
                    {
                        posicionMuñe.x += 1;
                    }
                break;
                case DezIzquierda:
                    
                    cosa = matInterpretada[posicionMuñe.y][posicionMuñe.x-1];
                    
                    if( puedeAvanzar(cosa) )
                    {
                    posicionMuñe.x -= 1;
                    }
                break;

                case -1:
                    //la direccion del muñeco no es conocida
                break;
            }
        
            if(matInterpretada[posicionMuñe.y][posicionMuñe.x]==Game.hieloDoble)
                matInterpretada[posicionMuñe.y][posicionMuñe.x]=Game.hielo;
            else
                matInterpretada[posicionMuñe.y][posicionMuñe.x]=Game.agua;
        
        pasos--;
        
        
        
        if(pasos<=0)
            tareaEjecutada = true;
    }

    /*public void desplazarMuñe()
    {
        switch (direccion)
            {
                case DezAbajo:
                    
                   dirMuñe.setY( velMuñe+dirMuñe.getY());
                    
                break;
                case DezArriba:
                    
                   
                    
                break;
                case DezDerecha:
                    
                    
                break;
                case DezIzquierda:
                    
                    dirMuñe.setX( -velMuñe+dirMuñe.getX() );
                   
                break;

                case -1:
                    //la direccion del muñeco no es conocida
                break;
            }
        
    }*/
    
    
    //si se encuentra cualquiera de estas cosas, no avanzará
    private boolean puedeAvanzar(int cosa)
    {
        if(cosa == Game.agua || cosa==Game.nada || cosa == Game.limite)
        {
            pasos=0;
            return false;
        }
        
        caminar.play();   
        return true;
    }
    
    

}



